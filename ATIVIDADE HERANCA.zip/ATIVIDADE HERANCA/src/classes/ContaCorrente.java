/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author dyogo
 */
 class ContaCorrente extends Conta {
    
    @Override
    public void deposita(double valor) {
        // Desconta taxa bancária de 1 real
        super.deposita(valor - 1);
    }

    @Override
    public void atualiza(double taxa) {
        super.atualiza(taxa * 2); // Atualiza-se com o dobro da taxa
    }
}


